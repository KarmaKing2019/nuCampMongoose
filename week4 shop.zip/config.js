module.exports = {
  secretKey: '12345-67890-09876-54321',
  mongoUrl: 'mongodb://localhost:27017/nucampsite',
      'facebook': {
        clientId: '134994185280506',
        clientSecret: '866f5714f7b755c7ce65bac86bf3cbfb'
    }
}
